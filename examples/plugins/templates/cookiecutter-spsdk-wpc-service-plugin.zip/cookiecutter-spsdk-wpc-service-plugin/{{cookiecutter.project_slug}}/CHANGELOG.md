
Change Log
==========

{{ cookiecutter.version }} ({% now 'local' %})
------------------

* First release on PyPI.
