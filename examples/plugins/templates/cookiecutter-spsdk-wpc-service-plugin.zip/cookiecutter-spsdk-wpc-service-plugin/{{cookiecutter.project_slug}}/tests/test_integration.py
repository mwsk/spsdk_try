#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Tests for `{{ cookiecutter.project_slug }}` package."""

from spsdk.wpc.utils import WPCCertificateService

from {{ cookiecutter.project_slug }} import {{ cookiecutter.service_provider_class }}


def test_registration() -> None:
    """Test whether {{ cookiecutter.service_provider_class }} got picked up by SPSDK."""
    assert {{ cookiecutter.service_provider_class }}.identifier in WPCCertificateService.get_providers()
